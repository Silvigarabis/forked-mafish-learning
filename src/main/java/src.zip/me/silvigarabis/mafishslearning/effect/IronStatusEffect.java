package me.silvigarabis.mafishslearning.effect;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;

public class IronStatusEffect extends StatusEffect {

    public IronStatusEffect(StatusEffectCategory category, int color) {
        super(category, color);
    }
}
