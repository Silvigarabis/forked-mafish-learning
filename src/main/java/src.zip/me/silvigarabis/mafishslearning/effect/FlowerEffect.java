package me.silvigarabis.mafishslearning.effect;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;

public class FlowerEffect  extends StatusEffect {
    public FlowerEffect(StatusEffectCategory category, int color) {
        super(category, color);
    }
}
